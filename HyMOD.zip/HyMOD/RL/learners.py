import copy
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

def as_batch(episodes, key, device, dtype=torch.float32):
    return torch.as_tensor(np.stack([e[key] for e in episodes]), device=device, dtype=dtype)

class TDLearner:

    def __init__(self, system, lr=0.0003, gamma=1.0, reward_scale=10000.0, grad_clip=10.0):
        self.system, self.target = (system, copy.deepcopy(system))
        self.target.requires_grad_(False)
        self.optimizer = torch.optim.Adam(system.parameters(), lr=lr)
        self.gamma, self.reward_scale = (gamma, reward_scale)
        self.grad_clip = grad_clip

    def update(self, episodes, trie):
        device = next(self.system.parameters()).device
        obs = as_batch(episodes, 'observations', device)
        states = as_batch(episodes, 'states', device)
        actions = as_batch(episodes, 'actions', device, torch.long)
        q_all = self.system(obs)
        chosen = q_all.gather(-1, actions[..., None]).squeeze(-1)
        b, t, _ = chosen.shape
        local = as_batch(episodes, 'local', device) / self.reward_scale
        with torch.no_grad():
            target_q = self.target(obs)
            selection_q = target_q
            next_values = torch.zeros_like(chosen)
            for j in range(t - 1):
                selected = np.array([trie.greedy_joint(e['next_nodes'][j], selection_q[k, j + 1].cpu().numpy())[0] for k, e in enumerate(episodes)])
                selected = torch.as_tensor(selected, device=device)
                next_values[:, j] = target_q[:, j + 1].gather(-1, selected[..., None]).squeeze(-1)
            if self.system.algorithm == 'iql':
                targets = self.gamma * next_values
                targets[:, -1] = local
            else:
                targets = torch.zeros((b, t), device=device)
                if t > 1:
                    targets[:, :-1] = self.gamma * self.target.mix(next_values[:, :-1], states[:, 1:])
                targets[:, -1] = local.sum(-1)
        predicted = chosen if self.system.algorithm == 'iql' else self.system.mix(chosen, states)
        loss = F.mse_loss(predicted, targets)
        if not torch.isfinite(loss):
            raise FloatingPointError('Nonfinite TD loss.')
        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.system.parameters(), self.grad_clip, error_if_nonfinite=True)
        self.optimizer.step()
        return float(loss.detach())

    def synchronize(self):
        self.target.load_state_dict(self.system.state_dict())

class PPOLearner:

    def __init__(self, system, lr=0.0003, gamma=1.0, reward_scale=10000.0, epochs=4, clip=0.2, value_coef=0.5, entropy_coef=0.01, grad_clip=1.0):
        self.system = system
        self.optimizer = torch.optim.Adam(system.parameters(), lr=lr)
        self.gamma, self.reward_scale, self.epochs = (gamma, reward_scale, epochs)
        self.clip, self.value_coef, self.entropy_coef = (clip, value_coef, entropy_coef)
        self.grad_clip = grad_clip

    def update(self, episodes):
        device = next(self.system.parameters()).device
        obs = as_batch(episodes, 'observations', device)
        states = as_batch(episodes, 'states', device)
        actions = as_batch(episodes, 'actions', device, torch.long)
        masks = as_batch(episodes, 'masks', device, torch.bool)
        old_logs = as_batch(episodes, 'old_logs', device)
        total = as_batch(episodes, 'local', device).sum(-1)[:, None] / self.reward_scale
        steps = states.shape[1]
        discounts = torch.as_tensor([self.gamma ** (steps - 1 - i) for i in range(steps)], device=device)
        returns = total * discounts[None, :]
        with torch.no_grad():
            values = self.system.centralized_critic(states).squeeze(-1)
            adv = returns - values
            adv = (adv - adv.mean()) / adv.std(unbiased=False).clamp_min(1e-06)
        for _ in range(self.epochs):
            logits = self.system(obs).masked_fill(~masks, -torch.inf)
            dist = torch.distributions.Categorical(logits=logits)
            ratio = (dist.log_prob(actions) - old_logs).exp()
            surrogate = torch.minimum(ratio * adv[..., None], ratio.clamp(1 - self.clip, 1 + self.clip) * adv[..., None])
            value = self.system.centralized_critic(states).squeeze(-1)
            loss = -surrogate.mean() + self.value_coef * F.mse_loss(value, returns) - self.entropy_coef * dist.entropy().mean()
            if not torch.isfinite(loss):
                raise FloatingPointError('Nonfinite PPO loss.')
            self.optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(self.system.parameters(), self.grad_clip, error_if_nonfinite=True)
            self.optimizer.step()
        return float(loss.detach())
