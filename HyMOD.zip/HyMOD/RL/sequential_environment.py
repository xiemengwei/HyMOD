"""Sequential GPU scheduling with per-round agent eligibility and deployment feasibility.

At each step, an eligible GPU deploys one model or takes a noop action
when its deployment is complete. Feasibility uses measured per-GPU groups.
"""
from collections import Counter
from functools import lru_cache
import numpy as np
from data import MissingData


class SequentialEnvironment:
    def __init__(self, scenario, data):
        self.layout = scenario
        self.data = data
        self.n = len(scenario.gpus)
        self.model_types = scenario.model_types
        self.model_index = {x: i for i, x in enumerate(self.model_types)}
        self.type_count = len(self.model_types)
        self.noop = self.type_count
        self.action_count = self.noop + 1
        self.total = tuple(Counter(scenario.models)[x] for x in self.model_types)
        self.total_count = len(scenario.models)
        self.all_acted = (1 << self.n) - 1
        self.variable_capacity = scenario.capacities is None

        self.group_lists = []
        self.group_vectors = []
        self.group_values = []
        max_group_sizes = []
        for i, gpu in enumerate(scenario.gpus):
            size = None if self.variable_capacity else scenario.capacities[i]
            groups = data.groups(gpu, size)
            unique = {}
            for group in groups:
                count = Counter(group)
                if count - Counter(scenario.models):
                    continue
                vector = tuple(count[x] for x in self.model_types)
                if not self.variable_capacity and len(group) != size:
                    continue
                value = float(data.table(gpu, len(group))[tuple(sorted(group))])
                unique[vector] = (tuple(sorted(group)), value)
            if not unique:
                raise MissingData(f'{gpu} 没有与当前场景匹配的完整部署组合。')
            self.group_lists.append(tuple(item[0] for item in unique.values()))
            self.group_vectors.append(tuple(unique.keys()))
            self.group_values.append(dict((vec, val[1]) for vec, val in unique.items()))
            max_group_sizes.append(max(map(sum, unique.keys())))

        if self.variable_capacity:
            self.capacities = np.array(max_group_sizes, dtype=np.float32)
            self.rounds = max(max_group_sizes)
        else:
            self.capacities = np.array(scenario.capacities, dtype=np.float32)
            self.rounds = int(max(scenario.capacities))
            if sum(scenario.capacities) != self.total_count:
                raise ValueError('固定GPU容量之和与模型数量不一致。')
        self.max_steps = self.rounds * self.n
        self.initial_node = (tuple([0] * (self.n * self.type_count)), 0, 0, 0)
        if not self._can_finish(self.initial_node[0], 0):
            raise MissingData('当前吞吐量JSON中找不到合法的完整部署方案。')

    def _counts(self, flat):
        return tuple(flat[i*self.type_count:(i+1)*self.type_count] for i in range(self.n))

    @lru_cache(maxsize=200000)
    def _can_finish(self, flat, closed_mask):
        """Exact completion feasibility using only measured complete GPU groups."""
        deployed = self._counts(flat)
        remaining = tuple(t - sum(c[k] for c in deployed) for k, t in enumerate(self.total))
        if any(v < 0 for v in remaining):
            return False
        choices = []
        for i in range(self.n):
            current = deployed[i]
            valid = []
            for group in self.group_vectors[i]:
                extra = tuple(g-c for c, g in zip(current, group))
                if any(v < 0 for v in extra) or any(v > r for v, r in zip(extra, remaining)):
                    continue
                if closed_mask & (1 << i) and any(extra):
                    continue
                valid.append(extra)
            if not valid:
                return False
            choices.append(valid)
        order = sorted(range(self.n), key=lambda i: len(choices[i]))

        @lru_cache(maxsize=None)
        def recurse(k, left):
            if k == self.n:
                return not any(left)
            for extra in choices[order[k]]:
                if all(v <= r for v, r in zip(extra, left)):
                    if recurse(k+1, tuple(r-v for v, r in zip(extra, left))):
                        return True
            return False
        return recurse(0, remaining)

    @lru_cache(maxsize=100000)
    def legal_actions(self, node):
        flat, acted, closed, step_index = node
        if step_index >= self.max_steps:
            return ()
        deployed = self._counts(flat)
        remaining = tuple(t - sum(c[k] for c in deployed) for k, t in enumerate(self.total))
        options = []
        for i in range(self.n):
            if acted & (1 << i):
                continue
            if closed & (1 << i):
                options.append((i, self.noop))
                continue
            # A GPU can deploy at most one model per scheduling round.
            if sum(deployed[i]) < int(self.capacities[i]):
                for a, amount in enumerate(remaining):
                    if amount == 0:
                        continue
                    updated = list(flat)
                    updated[i*self.type_count + a] += 1
                    if self._can_finish(tuple(updated), closed):
                        options.append((i, a))
            if self.variable_capacity and self._can_finish(flat, closed | (1 << i)):
                options.append((i, self.noop))
        return tuple(options)

    def step(self, node, agent, action):
        if (agent, action) not in self.legal_actions(node):
            raise ValueError(f'非法单动作: GPU={agent}, action={action}, step={node[-1]}')
        flat, acted, closed, step_index = node
        flat = list(flat)
        if action == self.noop:
            closed |= 1 << agent
        else:
            flat[agent*self.type_count + action] += 1
        acted |= 1 << agent
        if acted == self.all_acted:
            acted = 0
        return (tuple(flat), acted, closed, step_index + 1)

    def state(self, node):
        flat, _, _, _ = node
        counts = np.asarray(flat, dtype=np.float32).reshape(self.n, self.type_count)
        remaining = np.asarray(self.total, dtype=np.float32) - counts.sum(0)
        observations = np.concatenate([
            counts/5,
            np.tile(remaining/5, (self.n, 1)),
            np.eye(self.n, dtype=np.float32),
            (self.capacities-counts.sum(1))[:, None]/5,
        ], axis=1)
        global_state = np.concatenate([counts.ravel()/5, remaining/5, self.capacities/5])
        return observations.astype(np.float32), global_state.astype(np.float32)

    def outcome(self, node):
        flat, _, _, step_index = node
        if step_index != self.max_steps:
            raise ValueError('尚未完成全部调度步骤。')
        counts = self._counts(flat)
        if tuple(sum(c[k] for c in counts) for k in range(self.type_count)) != self.total:
            raise ValueError('终局模型数不正确。')
        groups = [[x for a, number in enumerate(row) for x in [self.model_types[a]]*number]
                  for row in counts]
        return self.data.score(self.layout, groups)[1], groups
