import torch
from torch import nn
from torch.nn import functional as F

class LocalDRQN(nn.Module):

    def __init__(self, observation_dim, hidden_dim, action_count):
        super().__init__()
        self.embedding = nn.Linear(observation_dim, hidden_dim)
        self.gru = nn.GRU(hidden_dim, hidden_dim, batch_first=True)
        self.head = nn.Linear(hidden_dim, action_count)

    def forward(self, observations):
        encoded = F.relu(self.embedding(observations))
        hidden, _ = self.gru(encoded)
        return self.head(hidden)

class AgentSystem(nn.Module):

    def __init__(self, agent_count, observation_dim, hidden_dim, action_count):
        super().__init__()
        self.agents = nn.ModuleList([LocalDRQN(observation_dim, hidden_dim, action_count) for _ in range(agent_count)])

    def forward(self, observations):
        return torch.stack([agent(observations[:, :, i]) for i, agent in enumerate(self.agents)], dim=2)
