from torch import nn
from torch.nn import functional as F
from networks import AgentSystem

class QMIXMixingNet(nn.Module):

    def __init__(self, state_dim, agent_count, hidden_dim=32):
        super().__init__()
        self.agent_count = agent_count
        self.hidden_dim = hidden_dim
        self.hyper_w1 = nn.Linear(state_dim, agent_count * hidden_dim)
        self.hyper_b1 = nn.Linear(state_dim, hidden_dim)
        self.hyper_w2 = nn.Linear(state_dim, hidden_dim)
        self.hyper_b2 = nn.Linear(state_dim, 1)

    def forward(self, local_q, state):
        w1 = self.hyper_w1(state).abs().unflatten(-1, (self.agent_count, self.hidden_dim))
        hidden = F.elu((local_q.unsqueeze(-2) @ w1).squeeze(-2) + self.hyper_b1(state))
        w2 = self.hyper_w2(state).abs()
        return (hidden * w2).sum(dim=-1) + self.hyper_b2(state).squeeze(-1)

class QMIXSystem(AgentSystem):
    algorithm = 'qmix'

    def __init__(self, agent_count, obs_dim, state_dim, hidden_dim, action_count):
        super().__init__(agent_count, obs_dim, hidden_dim, action_count)
        self.qmix_mixingnet = QMIXMixingNet(state_dim, agent_count, hidden_dim)

    def mix(self, local_q, state):
        return self.qmix_mixingnet(local_q, state)
