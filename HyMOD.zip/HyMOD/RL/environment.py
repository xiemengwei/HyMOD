from collections import Counter
import numpy as np
from data import MissingData

def make_plans(scenario, data, count=512, seed=0):
    rng = np.random.default_rng(seed)
    types = scenario.model_types
    total = Counter(scenario.models)
    initial = np.array([total[x] for x in types], dtype=np.int64)
    options = []
    for i, gpu in enumerate(scenario.gpus):
        size = None if scenario.capacities is None else scenario.capacities[i]
        groups = [group for group in data.groups(gpu, size) if not Counter(group) - total]
        if not groups:
            raise MissingData(f'{gpu} 的数据无法放入这个场景的model。')
        vectors = np.array([[Counter(group)[x] for x in types] for group in groups], dtype=np.int64)
        options.append((groups, vectors))
    n = len(options)
    minimum = np.zeros(n + 1, dtype=np.int64)
    maximum = np.zeros(n + 1, dtype=np.int64)
    coverage = np.zeros((n + 1, len(types)), dtype=np.int64)
    for i in range(n - 1, -1, -1):
        sums = options[i][1].sum(1)
        minimum[i] = minimum[i + 1] + sums.min()
        maximum[i] = maximum[i + 1] + sums.max()
        coverage[i] = coverage[i + 1] + options[i][1].max(0)
    lookup = [{tuple(group): group for group in groups} for groups, _ in options]

    def search(i, remaining, selected, budget):
        budget[0] -= 1
        if budget[0] < 0 or (remaining > coverage[i]).any():
            return None
        left = int(remaining.sum())
        if left < minimum[i] or left > maximum[i]:
            return None
        if i == n:
            return selected if left == 0 else None
        if i == n - 1:
            group = tuple((x for x, number in zip(types, remaining) for _ in range(int(number))))
            return selected + [lookup[i][group]] if group in lookup[i] else None
        groups, vectors = options[i]
        possible = (vectors <= remaining).all(1)
        next_count = left - vectors.sum(1)
        possible &= (next_count >= minimum[i + 1]) & (next_count <= maximum[i + 1])
        choices = np.flatnonzero(possible)
        for index in rng.permutation(choices):
            found = search(i + 1, remaining - vectors[index], selected + [groups[int(index)]], budget)
            if found is not None:
                return found
            if budget[0] < 0:
                break
        return None
    plans = {}
    for _ in range(max(100, count * 4)):
        plan = search(0, initial, [], [400])
        if plan is not None:
            plans[tuple(plan)] = [list(group) for group in plan]
        if len(plans) >= count:
            break
    if not plans:
        raise MissingData('当前吞吐量数据无法分配完这个场景的所有model。')
    return list(plans.values())

class Environment:

    def __init__(self, scenario, data, plans, seed=0):
        self.layout = scenario
        self.n = len(scenario.gpus)
        self.model_types = scenario.model_types
        self.model_index = {x: i for i, x in enumerate(self.model_types)}
        self.noop = len(self.model_types)
        self.action_count = self.noop + 1
        self.rounds = max((len(group) for plan in plans for group in plan))
        self.capacities = np.array([max((len(plan[i]) for plan in plans)) for i in range(self.n)], dtype=np.float32)
        self.children, self.prefixes = ([{}], [[]])
        self.leaf_groups, self.local_scores = ({}, {})
        rng = np.random.default_rng(seed)
        for groups in plans:
            shuffled = [rng.permutation(group).tolist() for group in groups]
            flat = [self.model_index[shuffled[i][t]] if t < len(shuffled[i]) else self.noop for t in range(self.rounds) for i in range(self.n)]
            node = 0
            for action in flat:
                if action not in self.children[node]:
                    child = len(self.children)
                    self.children[node][action] = child
                    self.children.append({})
                    self.prefixes.append(self.prefixes[node] + [action])
                node = self.children[node][action]
            self.leaf_groups[node] = groups
            self.local_scores[node] = data.score(scenario, groups)[1]

    def mask(self, node):
        mask = np.zeros(self.action_count, dtype=bool)
        mask[list(self.children[node])] = True
        return mask

    def greedy_joint(self, node, q_values):
        actions = []
        for i in range(self.n):
            action = max(self.children[node], key=lambda a: float(q_values[i, a]))
            actions.append(action)
            node = self.children[node][action]
        return (np.array(actions), node)

    def state(self, node):
        counts = np.zeros((self.n, len(self.model_types)), dtype=np.float32)
        for position, action in enumerate(self.prefixes[node]):
            if action != self.noop:
                counts[position % self.n, action] += 1
        totals = Counter(self.layout.models)
        remaining = np.array([totals[x] for x in self.model_types], dtype=np.float32) - counts.sum(0)
        observations = np.concatenate([counts / 5, np.tile(remaining / 5, (self.n, 1)), np.eye(self.n, dtype=np.float32), (self.capacities - counts.sum(1))[:, None] / 5], axis=1)
        state = np.concatenate([counts.ravel() / 5, remaining / 5, self.capacities / 5])
        return (observations.astype(np.float32), state.astype(np.float32))
