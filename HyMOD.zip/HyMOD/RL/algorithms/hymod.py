import math
import torch
from torch import nn
from torch.nn import functional as F
from networks import AgentSystem
ACTIVATIONS = ('prelu', 'tanh', 'leakyrelu', 'elu', 'relu', 'silu')

def activation(name):
    factories = dict(prelu=nn.PReLU, tanh=nn.Tanh, leakyrelu=lambda: nn.LeakyReLU(0.01), elu=nn.ELU, relu=nn.ReLU, silu=nn.SiLU)
    if name not in factories:
        raise ValueError(f'Unknown HHN activation: {name}')
    return factories[name]()

class HybridHypernetwork(nn.Module):

    def __init__(self, state_dim, agent_count, hidden_dim, activations):
        super().__init__()
        names = activations.split(',') if isinstance(activations, str) else list(activations)
        if len(names) != 4:
            raise ValueError('Supply four activations in w1,b1,w2,b2 order.')
        self.activation_names = tuple(names)
        self.agent_count = agent_count
        self.hidden_dim = hidden_dim

        def head(output_dim, name):
            return nn.Sequential(nn.Linear(state_dim, hidden_dim), activation(name), nn.Linear(hidden_dim, output_dim))
        self.weight_in = head(agent_count * hidden_dim, names[0])
        self.bias_in = head(hidden_dim, names[1])
        self.weight_out = head(hidden_dim * agent_count, names[2])
        self.bias_out = head(agent_count, names[3])

    def forward(self, state):
        w1 = F.softplus(self.weight_in(state)).unflatten(-1, (self.agent_count, self.hidden_dim))
        w2 = F.softplus(self.weight_out(state)).unflatten(-1, (self.hidden_dim, self.agent_count))
        return w1, self.bias_in(state), w2, self.bias_out(state)

class HyMOD_mixingnet(nn.Module):

    def __init__(self, state_dim, agent_count, hidden_dim=32, beta=1.0, activations='prelu,tanh,leakyrelu,elu'):
        super().__init__()
        if not math.isfinite(beta) or beta <= 0:
            raise ValueError('LSE beta must be finite and positive.')
        self.beta = beta
        self.hybrid_hypernetwork = HybridHypernetwork(state_dim, agent_count, hidden_dim, activations)

    def forward(self, local_q, state):
        w1, b1, w2, b2 = self.hybrid_hypernetwork(state)
        hidden = F.elu((local_q.unsqueeze(-2) @ w1).squeeze(-2) + b1)
        scores = (hidden.unsqueeze(-2) @ w2).squeeze(-2) + b2
        # Reduce only the N scores; batch and time dimensions stay intact.
        return torch.logsumexp(self.beta * scores, dim=-1) / self.beta

class HyMODSystem(AgentSystem):
    algorithm = 'hymod'

    def __init__(self, agent_count, obs_dim, state_dim, hidden_dim, action_count, mixing_hidden=32, beta=1.0, activations='prelu,tanh,leakyrelu,elu'):
        super().__init__(agent_count, obs_dim, hidden_dim, action_count)
        self.hymod_mixingnet = HyMOD_mixingnet(state_dim, agent_count, mixing_hidden, beta, activations)

    def mix(self, local_q, state):
        return self.hymod_mixingnet(local_q, state)
