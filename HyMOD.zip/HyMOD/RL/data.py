import json
import math
import re
from collections import Counter
from pathlib import Path

class MissingData(ValueError):
    pass

class Data:

    def __init__(self, directory, gpus):
        self.values = {}
        directory = Path(directory)
        if not directory.is_dir():
            raise FileNotFoundError(f'数据目录不存在：{directory}')
        for path in sorted(directory.iterdir()):
            if path.suffix.lower() != '.json':
                continue
            matches = [gpu for gpu in set(gpus) if re.search('(?<![A-Za-z0-9])' + re.escape(gpu) + '(?![A-Za-z0-9])', path.stem, re.I)]
            if len(matches) != 1:
                continue
            gpu = matches[0]
            raw = json.loads(path.read_text(encoding='utf-8-sig'))
            if not isinstance(raw, dict):
                continue
            rows = raw.items()
            for key, value in rows:
                if not isinstance(key, str) or not re.fullmatch('\\s*\\d+(?:[\\s,;]+\\d+)*\\s*', key):
                    continue
                models = tuple(sorted(map(int, re.split('[\\s,;]+', key.strip()))))
                value = float(value)
                if not math.isfinite(value) or value < 0:
                    raise ValueError(f'吞吐量不是有效数值：{path.name}，{key}')
                table = self.values.setdefault((gpu, len(models)), {})
                if models in table and table[models] != value:
                    raise ValueError(f'同一个GPU上的同一组model有两个不同吞吐量：{path.name}，{key}')
                table[models] = value
        for gpu in set(gpus):
            if not any((name == gpu for name, _ in self.values)):
                raise MissingData(f'数据目录中没有 {gpu} 的吞吐量JSON。')

    def table(self, gpu, size):
        if size == 0:
            return {(): 0.0}
        try:
            return self.values[gpu, size]
        except KeyError:
            raise MissingData(f'缺少 {gpu} 同时运行 {size} 个model的吞吐量数据。') from None

    def groups(self, gpu, size=None):
        if size is not None:
            return list(self.table(gpu, size))
        return [()] + [group for (name, _), table in self.values.items() if name == gpu for group in table]

    def score(self, scenario, groups):
        if len(groups) != len(scenario.gpus) or Counter((x for group in groups for x in group)) != Counter(scenario.models):
            raise ValueError('分配后的model数量或GPU数量不对。')
        if scenario.capacities is not None and list(map(len, groups)) != scenario.capacities:
            raise ValueError('每张GPU上的model数量不对。')
        scores = [self.table(gpu, len(group))[tuple(sorted(group))] for gpu, group in zip(scenario.gpus, groups)]
        return (float(sum(scores)), scores)
