# HyMOD

HyMOD is a multi-agent reinforcement learning framework for model placement on heterogeneous GPUs. This repository also includes implementations of QMIX, MAPPO, VDN, and IQL for evaluation.

## Setup

```bash
pip install -r requirements.txt
```

Provide a directory containing the throughput measurement JSON files for the GPU types used by the selected scenario. The loader matches GPU types to filenames and reads measured throughput for model combinations.

## Training

Run HyMOD on the 5x3 scenario:

```bash
python train.py --scenario 5x3 --algorithm hymod --data-dir /path/to/json --episodes 1500 --device cuda:0 --output results
```

Run all methods on the 5x3 scenario:

```bash
python train.py --scenario 5x3 --algorithm all --data-dir /path/to/json --episodes 4500 --device cuda:0 --output results
```

Run all available scenarios with `--scenario all`. Supported scenarios are `5x3`, `5x4`, `5x5`, `6x5`, `8gpus`, and `10x3`. Use `--seed` to set the random seed and `--output` to select the results directory.

Per-episode throughput values are written to `results/<scenario>/<algorithm>/training.txt`.

# 

## Figures

The `plot/` directory contains MATLAB functions for generating the evaluation figures. See `plot/README.md` for the available scripts.
