import copy
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from actions import best_feasible_single
from learners import as_batch


class HyMODLearner:
    def __init__(self, system, lr=0.0003, reward_scale=10000.0,
                 trace_lambda=0.8, target_tau=0.02, grad_clip=10.0):
        self.system = system
        self.target = copy.deepcopy(system)
        self.target.requires_grad_(False)
        self.optimizer = torch.optim.Adam(system.parameters(), lr=lr)
        self.reward_scale = reward_scale
        self.trace_lambda = trace_lambda
        self.target_tau = target_tau
        self.grad_clip = grad_clip

    @staticmethod
    def _next_action_vector(env, node, q):
        agent, action = best_feasible_single(env, node, q)
        vector = np.full(env.n, env.noop, dtype=np.int64)
        vector[agent] = action
        return vector

    def update(self, episodes, env):
        device = next(self.system.parameters()).device
        observations = as_batch(episodes, 'observations', device)
        states = as_batch(episodes, 'states', device)
        actions = as_batch(episodes, 'actions', device, torch.long)
        local_rewards = as_batch(episodes, 'local', device) / self.reward_scale
        online_q = self.system(observations)
        chosen_q = online_q.gather(-1, actions.unsqueeze(-1)).squeeze(-1)
        predicted = self.system.mix(chosen_q, states)
        batch, steps = predicted.shape
        with torch.no_grad():
            target_q = self.target(observations)
            bootstrap = torch.zeros_like(predicted)
            trace = torch.zeros_like(predicted)
            for step in range(steps-1):
                selected = np.array([
                    self._next_action_vector(env, episode['next_nodes'][step],
                                             online_q[row, step+1].detach())
                    for row, episode in enumerate(episodes)
                ])
                selected = torch.as_tensor(selected, device=device)
                next_q = target_q[:,step+1].gather(-1, selected.unsqueeze(-1)).squeeze(-1)
                bootstrap[:,step] = self.target.mix(next_q, states[:,step+1])
                on_policy = (selected == actions[:,step+1]).all(dim=-1)
                trace[:,step] = self.trace_lambda * on_policy
            targets = torch.zeros_like(predicted)
            targets[:,-1] = local_rewards.sum(dim=-1)
            for step in range(steps-2,-1,-1):
                targets[:,step] = ((1-trace[:,step])*bootstrap[:,step]
                                       + trace[:,step]*targets[:,step+1])
        loss = F.smooth_l1_loss(predicted, targets)
        if not torch.isfinite(loss):
            raise FloatingPointError('HyMOD loss is not finite.')
        self.optimizer.zero_grad(set_to_none=True)
        loss.backward()
        nn.utils.clip_grad_norm_(self.system.parameters(), self.grad_clip, error_if_nonfinite=True)
        self.optimizer.step()
        with torch.no_grad():
            for target,online in zip(self.target.parameters(), self.system.parameters()):
                target.lerp_(online, self.target_tau)
        return float(loss.detach())
