from dataclasses import dataclass
GPUS = ['4090', 'V100', 'A100', 'H20', 'H800']
MODELS = [1, 3, 5, 7, 9, 11, 12, 15, 17, 2, 4, 6, 1, 6, 9, 1, 3, 5, 7, 9, 11, 12, 15, 17, 2, 4, 6, 1, 6, 9]
SCENARIOS = {'5x3': (GPUS, MODELS[:15], [3] * 5), '5x4': (GPUS, MODELS[:20], [4] * 5), '5x5': (GPUS, MODELS[:25], [5] * 5), '6x5': (GPUS + ['H800'], MODELS, [5] * 6), '8gpus': (GPUS + ['4090', 'A100', 'H800'], MODELS, None), '10x3': (GPUS * 2, MODELS, [3] * 10)}

@dataclass
class Scenario:
    name: str
    gpus: list
    models: list
    capacities: object

    @property
    def model_types(self):
        return sorted(set(self.models))

def get_scenario(name):
    gpus, models, capacities = SCENARIOS[name]
    return Scenario(name, list(gpus), list(models), None if capacities is None else list(capacities))
