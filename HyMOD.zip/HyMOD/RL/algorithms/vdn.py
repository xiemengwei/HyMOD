from networks import AgentSystem

class VDNSystem(AgentSystem):
    algorithm = 'vdn'

    def mix(self, local_q, state):
        return local_q.sum(-1)
