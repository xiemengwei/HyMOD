import numpy as np
import torch

@torch.no_grad()
def rollout(system, trie, rng, epsilon=0.0, deterministic=False):
    node = 0
    observations, states, actions, masks, old_logs, next_nodes = ([], [], [], [], [], [])
    device = next(system.parameters()).device
    if system.algorithm == 'hymod':
        raise ValueError('HyMOD 必须使用 rollout_sequential_hymod。')
    actor = system.algorithm == 'mappo'
    for _ in range(trie.rounds):
        obs, state = trie.state(node)
        observations.append(obs)
        states.append(state)
        scores = system(torch.as_tensor(np.array(observations)[None], device=device))[0, -1]
        joint, joint_masks, joint_logs = ([], [], [])
        for i in range(trie.n):
            mask = trie.mask(node)
            logits = scores[i].masked_fill(~torch.as_tensor(mask, device=device), -torch.inf)
            if actor:
                dist = torch.distributions.Categorical(logits=logits)
                action = int(logits.argmax()) if deterministic else int(dist.sample())
                logp = float(dist.log_prob(torch.tensor(action, device=device)))
            else:
                candidates = np.flatnonzero(mask)
                if not deterministic and rng.random() < epsilon:
                    action = int(rng.choice(candidates))
                else:
                    action = int(logits.argmax())
                logp = 0.0
            node = trie.children[node][action]
            joint.append(action)
            joint_masks.append(mask)
            joint_logs.append(logp)
        actions.append(joint)
        masks.append(joint_masks)
        old_logs.append(joint_logs)
        next_nodes.append(node)
    local = np.array(trie.local_scores[node], dtype=np.float64)
    return dict(observations=np.array(observations), states=np.array(states), actions=np.array(actions), masks=np.array(masks), old_logs=np.array(old_logs), next_nodes=next_nodes, local=local, throughput=float(local.sum()), groups=trie.leaf_groups[node])


@torch.no_grad()
def best_feasible_single(env, node, local_q):
    """Return (agent, model_action), maximizing raw local Q over legal pairs."""
    feasible = env.legal_actions(node)
    if not feasible:
        raise RuntimeError('没有可选的合法单动作。')
    return max(feasible, key=lambda pair: float(local_q[pair[0], pair[1]]))


@torch.no_grad()
def rollout_sequential_hymod(system, env, rng, epsilon=0.0, deterministic=False):
    """One action per time step; every GPU acts at most once per round.

    The only selected model action is recorded for its GPU; every other GPU
    contributes its noop baseline Q to the mixing network training input.
    """
    node = env.initial_node
    observations, states, actions, masks, old_logs, next_nodes = ([], [], [], [], [], [])
    selected_agents, selected_actions = [], []
    device = next(system.parameters()).device
    for _ in range(env.max_steps):
        obs, state = env.state(node)
        observations.append(obs)
        states.append(state)
        q_values = system(torch.as_tensor(np.stack(observations)[None], device=device))[0, -1]
        feasible = env.legal_actions(node)
        if not feasible:
            raise RuntimeError('单动作调度提前陷入死路。')
        if not deterministic and rng.random() < epsilon:
            agent, action = feasible[int(rng.integers(len(feasible)))]
        else:
            agent, action = best_feasible_single(env, node, q_values)
        # Other branches use their noop Q as fixed-state baseline.
        vector = np.full(env.n, env.noop, dtype=np.int64)
        vector[agent] = action
        mask = np.zeros((env.n, env.action_count), dtype=bool)
        for i, a in feasible:
            mask[i, a] = True
        node = env.step(node, agent, action)
        actions.append(vector)
        masks.append(mask)
        old_logs.append(np.zeros(env.n, dtype=np.float32))
        next_nodes.append(node)
        selected_agents.append(agent)
        selected_actions.append(action)
    local, groups = env.outcome(node)
    local = np.array(local, dtype=np.float64)
    return dict(observations=np.asarray(observations), states=np.asarray(states),
                actions=np.asarray(actions), masks=np.asarray(masks),
                old_logs=np.asarray(old_logs), next_nodes=next_nodes, local=local,
                throughput=float(local.sum()), groups=groups,
                selected_agents=np.asarray(selected_agents),
                selected_actions=np.asarray(selected_actions))
