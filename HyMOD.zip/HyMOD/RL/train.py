import argparse
import random
from collections import deque
from pathlib import Path
import numpy as np
import torch
from algorithms import make_system
from actions import rollout, rollout_sequential_hymod
from data import Data
from environment import Environment, make_plans
from sequential_environment import SequentialEnvironment
from learners import PPOLearner, TDLearner
from hymod_learner import HyMODLearner
from scenarios import SCENARIOS, get_scenario
ALGORITHMS = {'hymod': 'HyMOD', 'qmix': 'QMIX', 'mappo': 'MAPPO', 'vdn': 'VDN', 'iql': 'IQL'}

def train(scenario, data, env, algorithm, args):
    output = Path(args.output) / scenario.name / ALGORITHMS[algorithm]
    training_file = output / 'training.txt'
    if training_file.exists():
        raise FileExistsError(f'{training_file} 已存在，请用 --output 选择新的保存目录。')
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    rng = np.random.default_rng(args.seed)
    observations, state = env.state(env.initial_node if algorithm == 'hymod' else 0)
    system = make_system(algorithm, env.n, observations.shape[-1], len(state), env.action_count, args).to(args.device)
    actor = algorithm == 'mappo'
    if algorithm == 'hymod':
        learner = HyMODLearner(system, args.lr, args.reward_scale,
                               args.td_lambda, args.target_tau)
    elif actor:
        learner = PPOLearner(system, args.lr, reward_scale=args.reward_scale)
    else:
        learner = TDLearner(system, args.lr, reward_scale=args.reward_scale)
    replay, pending = (deque(maxlen=2048), [])
    output.mkdir(parents=True, exist_ok=True)
    recent = deque(maxlen=100)
    with training_file.open('w', encoding='utf-8') as training:
        for episode in range(args.episodes):
            fraction = episode / max(1, args.episodes - 1)
            epsilon = 1.0 + (args.epsilon_end - 1.0) * fraction
            sampled = (rollout_sequential_hymod(system, env, rng, epsilon)
                       if algorithm == 'hymod' else rollout(system, env, rng, epsilon))
            if actor:
                pending.append(sampled)
                if len(pending) >= args.batch_size or episode + 1 == args.episodes:
                    learner.update(pending)
                    pending = []
            else:
                replay.append(sampled)
                if len(replay) >= args.batch_size:
                    indices = rng.choice(len(replay), args.batch_size, replace=False)
                    learner.update([replay[int(i)] for i in indices], env)
                if algorithm != 'hymod' and (episode + 1) % 50 == 0:
                    learner.synchronize()
            training.write(f"{sampled['throughput']:.17g}\n")
            recent.append(sampled['throughput'])
            if (episode + 1) % 100 == 0 or episode + 1 == args.episodes:
                training.flush()
                print(f"{scenario.name} {ALGORITHMS[algorithm]} {episode + 1}/{args.episodes}  {np.mean(recent):.3f}", flush=True)

def main():
    parser = argparse.ArgumentParser(description='HyMOD、QMIX、MAPPO、VDN、IQL训练')
    parser.add_argument('--scenario', choices=[*SCENARIOS, 'all'], default='5x3', help='选择场景，all 表示六个场景')
    parser.add_argument('--algorithm', type=str.lower, choices=[*ALGORITHMS, 'all'], default='all', help='选择算法，默认全部五种')
    parser.add_argument('--data-dir', required=True, help='吞吐量JSON所在的目录')
    parser.add_argument('--episodes', required=True, type=int, help='训练轮数')
    parser.add_argument('--device', default='cpu', help='cpu 或 cuda:0')
    parser.add_argument('--output', default='results', help='结果保存目录')
    parser.add_argument('--lr', type=float, default=0.0003, help='学习率')
    parser.add_argument('--hidden', type=int, default=32, help='QMIX、VDN、IQL的隐藏层大小')
    parser.add_argument('--batch-size', type=int, default=8, help='每次更新使用多少条训练记录')
    parser.add_argument('--reward-scale', type=float, default=10000.0, help='训练时的奖励归一化，不改变TXT里的数值')
    parser.add_argument('--epsilon-end', type=float, default=0.01, help='最后一轮的探索概率')
    parser.add_argument('--plans', type=int, default=512, help='QMIX、MAPPO、VDN、IQL 的部署方案采样数量')
    parser.add_argument('--hymod-hidden', type=int, default=64, help='HyMOD的GRU和超网络隐藏层大小')
    parser.add_argument('--td-lambda', type=float, default=0.8, help='HyMOD多步回报系数')
    parser.add_argument('--target-tau', type=float, default=0.02, help='HyMOD目标网络更新比例')
    parser.add_argument('--seed', type=int, default=0, help='随机种子')
    args = parser.parse_args()
    if min(args.episodes, args.hidden, args.hymod_hidden, args.batch_size, args.plans) < 1 or args.batch_size > 2048:
        parser.error('轮数、隐藏层和批量大小需要为正数；批量大小不能超过2048。')
    if not np.isfinite(args.lr) or args.lr <= 0 or (not np.isfinite(args.reward_scale)) or (args.reward_scale <= 0):
        parser.error('学习率和奖励归一化系数需要为正数。')
    if not 0 <= args.epsilon_end <= 1 or args.seed < 0:
        parser.error('探索概率应在0到1之间，随机种子不能为负数。')
    if not 0 <= args.td_lambda <= 1 or not 0 < args.target_tau <= 1:
        parser.error('td-lambda需要在0到1之间，target-tau需要大于0且不超过1。')
    torch.set_num_threads(1)
    if args.device.isdigit():
        args.device = 'cuda:' + args.device
    if args.device.startswith('cuda'):
        torch.cuda.set_device(torch.device(args.device))
    scenarios = list(SCENARIOS) if args.scenario == 'all' else [args.scenario]
    algorithms = list(ALGORITHMS) if args.algorithm == 'all' else [args.algorithm]
    for name in scenarios:
        scenario = get_scenario(name)
        data = Data(args.data_dir, scenario.gpus)
        for algorithm in algorithms:
            if algorithm == 'hymod':
                env = SequentialEnvironment(scenario, data)
            else:
                plans = make_plans(scenario, data, args.plans)
                env = Environment(scenario, data, plans)
            train(scenario, data, env, algorithm, args)
if __name__ == '__main__':
    main()
